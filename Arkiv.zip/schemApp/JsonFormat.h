//
//  JsonFormat.h
//  schemApp
//
//  Created by sebastian holmqvist on 2013-09-12.
//  Copyright (c) 2013 sebastian holmqvist. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JsonFormat <NSObject>
-(id) jsonValue;

@end
