//
//  Message+Json.h
//  schemApp
//
//  Created by sebastian holmqvist on 2013-09-12.
//  Copyright (c) 2013 sebastian holmqvist. All rights reserved.
//

#import "SendMessage.h"
#import "JsonFormat.h"

@interface SendMessage (Json) <JsonFormat>

@end
