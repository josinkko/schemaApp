//
//  StudentMethods.m
//  schemApp
//
//  Created by sebastian holmqvist on 2013-09-11.
//  Copyright (c) 2013 sebastian holmqvist. All rights reserved.
//

#import "StudentMethods.h"

@implementation StudentMethods

@end
